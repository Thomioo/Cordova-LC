#import <Foundation/Foundation.h>
#import "SM_AFURLResponseSerialization.h"

@interface TextResponseSerializer : SM_AFHTTPResponseSerializer

+ (instancetype)serializer;

@end
